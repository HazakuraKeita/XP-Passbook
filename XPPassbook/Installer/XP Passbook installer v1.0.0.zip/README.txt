///////////////////////////////////////////////////////////
///
/// XP Passbook
/// version 1.0.0
///
///////////////////////////////////////////////////////////

# How to install

Please double click on setup.exe.
Then, please follow installer guidance (Generally, it is ok to click OK in all cases).

# How to launch

XP Passbook shortcut is created in Desktop.
Please look for the shortcut icon.
If you cannot find it, you can launch it from "C:\Program Files (x86)\XpJp\XPPassbook\XPPassbook.exe" too.